package model;

/**
 * Created by admin on 2017/3/30.
 */

public class ExpressPersonStatisticsXiangqing {
    private String time;
    private String name;
    private String numeric;
    private String description;
    private String id;
    private String type;
    private String type1;
    private String name_id;

    public ExpressPersonStatisticsXiangqing(String time, String name, String numeric, String description, String id, String type, String type1, String name_id) {
        this.time = time;
        this.name = name;
        this.numeric = numeric;
        this.description = description;
        this.id = id;
        this.type = type;
        this.type1 = type1;
        this.name_id = name_id;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getNumeric() {
        return numeric;
    }

    public void setNumeric(String numeric) {
        this.numeric = numeric;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getType1() {
        return type1;
    }

    public void setType1(String type1) {
        this.type1 = type1;
    }

    public String getName_id() {
        return name_id;
    }

    public void setName_id(String name_id) {
        this.name_id = name_id;
    }
}
