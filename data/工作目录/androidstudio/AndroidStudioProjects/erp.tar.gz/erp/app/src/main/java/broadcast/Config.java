package broadcast;

/**
 * Created by liyanippon on 17/04/03.
 */

public class Config {
    public static String BC_ONE = "com.example.testbroadcast.bcone";
}
