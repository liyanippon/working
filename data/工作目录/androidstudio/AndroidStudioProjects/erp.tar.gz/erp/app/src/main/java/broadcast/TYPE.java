package broadcast;

/**
 * Created by liyanippon on 17/04/03.
 */

public enum TYPE {
    NORMAL
}
