package portface;

/**
 * Created by admin on 2017/3/8.
 */

public interface LazyLoadFace {
    void AdapterRefresh(String type);//刷新适配器
}
