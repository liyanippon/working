/** Automatically generated file. DO NOT MODIFY */
package jerome.news;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}