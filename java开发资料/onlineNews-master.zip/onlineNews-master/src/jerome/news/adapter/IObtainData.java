package jerome.news.adapter;

import jerome.news.data.NewsBrief;

public interface IObtainData {

	public void updateNewsBrief(NewsBrief newsBrief);
}
