//
//  APWebViewController.h
//  AliSDKDemo
//
//  Created by 亦澄 on 16-1-5.
//  Copyright (c) 2016年 Alipay. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface APWebViewController : UIViewController<UIWebViewDelegate>


@property (strong, nonatomic) IBOutlet UIWebView *webView;

@end
