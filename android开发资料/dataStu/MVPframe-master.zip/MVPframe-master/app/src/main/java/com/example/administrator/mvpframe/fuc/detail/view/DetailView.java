package com.example.administrator.mvpframe.fuc.detail.view;

import com.example.administrator.mvpframe.common.base.baseView.BaseView;

public interface DetailView extends BaseView{

    void showContent(String content);
}
