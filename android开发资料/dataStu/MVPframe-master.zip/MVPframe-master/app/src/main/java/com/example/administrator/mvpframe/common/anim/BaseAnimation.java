package com.example.administrator.mvpframe.common.anim;

import android.animation.Animator;
import android.view.View;

public interface  BaseAnimation {

    Animator[] getAnimators(View view);

}
