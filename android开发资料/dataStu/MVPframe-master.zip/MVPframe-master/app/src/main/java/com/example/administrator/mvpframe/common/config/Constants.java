package com.example.administrator.mvpframe.common.config;

public interface Constants {

    String BASE_URL = "http://v.juhe.cn/";
}
