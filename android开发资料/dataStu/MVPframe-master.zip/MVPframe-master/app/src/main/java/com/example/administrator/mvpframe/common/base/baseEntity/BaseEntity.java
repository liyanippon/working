package com.example.administrator.mvpframe.common.base.baseEntity;

public class BaseEntity {

    public String reason;

    public int error_code;
}
