package cn.droidlover.xdroid.demo.model;

/**
 * Created by wanglei on 2016/12/11.
 */

public class BaseModel {
    protected boolean error;


    public boolean isError() {
        return error;
    }

    public void setError(boolean error) {
        this.error = error;
    }
}
