package cn.droidlover.xdroid.kit;

/**
 * Created by wanglei on 2016/12/1.
 */
public interface SimpleCallback<T> {
    void action(T data);
}
