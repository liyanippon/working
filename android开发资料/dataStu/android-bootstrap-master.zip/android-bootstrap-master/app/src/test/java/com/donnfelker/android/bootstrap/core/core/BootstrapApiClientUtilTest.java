

package com.donnfelker.android.bootstrap.core.core;


import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.BlockJUnit4ClassRunner;

import static org.junit.Assert.assertTrue;

/**
 * Unit tests of client API
 */
@RunWith(BlockJUnit4ClassRunner.class)
public class BootstrapApiClientUtilTest {

    @Test
    public void simpleTest() {
        assertTrue(1 == 1);
    }
}
