package com.donnfelker.android.bootstrap.core;

import java.util.List;

public class CheckInWrapper {
    private List<CheckIn> results;

    public List<CheckIn> getResults() {
        return results;
    }
}
