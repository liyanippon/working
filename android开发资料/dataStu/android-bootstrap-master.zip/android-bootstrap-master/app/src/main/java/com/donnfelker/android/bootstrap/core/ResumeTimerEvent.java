package com.donnfelker.android.bootstrap.core;

/**
 * Marker class for resuming a timer through Otto
 */
public class ResumeTimerEvent {
}
