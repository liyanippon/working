package com.donnfelker.android.bootstrap.core;

/**
 * Marker class for Otto for a pause event for the timer.
 */
public class PauseTimerEvent {
}
