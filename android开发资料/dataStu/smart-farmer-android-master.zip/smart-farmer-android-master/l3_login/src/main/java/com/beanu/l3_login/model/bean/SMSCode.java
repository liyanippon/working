package com.beanu.l3_login.model.bean;

/**
 * 短信验证码
 * Created by Beanu on 2017/2/13.
 */

public class SMSCode {

    private String code;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }
}
