package com.beanu.l3_login.ui;

import android.os.Bundle;

import com.beanu.arad.base.ToolBarActivity;
import com.beanu.l3_login.R;

public class LoginActivity extends ToolBarActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
    }
}
