package com.beanu.l3_login;

/**
 * 更改这里的值  改变登录方式
 * Created by Beanu on 2017/3/2.
 */

public class SignInMode {

    /**
     * 1=手机号  验证码  密码
     * 2=手机号  验证码  密码 头像 昵称
     */
    public static final int MODE = 2;

}
