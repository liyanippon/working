package com.beanu.l2_recycleview.demo.loadmore;

/**
 * Created by Beanu on 2016/12/20
 */

public class DemoLoadMorePresenterImpl extends DemoLoadMoreContract.Presenter {

}