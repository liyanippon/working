package com.beanu.l2_recycleview.demo.support;

/**
 * 新闻类
 * Created by Beanu on 2016/12/16.
 */

public class News {

    private String imgPath;
    private String title;
    private String desc;

    public String getImgPath() {
        return imgPath;
    }

    public void setImgPath(String imgPath) {
        this.imgPath = imgPath;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }
}
