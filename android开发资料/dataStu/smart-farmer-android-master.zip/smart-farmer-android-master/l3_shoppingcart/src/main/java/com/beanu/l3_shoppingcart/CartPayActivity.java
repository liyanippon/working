package com.beanu.l3_shoppingcart;

import android.os.Bundle;

import com.beanu.arad.base.ToolBarActivity;

/**
 * 购物车支付
 */
public class CartPayActivity extends ToolBarActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.cart_activity_pay);
    }
}
