package com.beanu.l3_shoppingcart.demo;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.beanu.l3_shoppingcart.R;

public class DemoActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.cart_activity_demo);
    }
}
