package com.beanu.l4_clean.ui.signIn;

import android.os.Bundle;

import com.beanu.arad.base.BaseActivity;
import com.beanu.l4_clean.R;


public class LoginActivity extends BaseActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
    }

}
