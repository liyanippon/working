package com.beanu.l4_clean.model.bean;

import java.io.Serializable;

/**
 * 用户信息
 * Created by Beanu on 16/2/23.
 */
public class User implements Serializable{

}
