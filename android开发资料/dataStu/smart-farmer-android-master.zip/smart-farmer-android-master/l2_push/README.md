## 推送

## 使用说明

### 步骤一
### 步骤二
### 步骤三



##更新日志
    2017-02-10
        1. 添加华为推送
        2. 不同机型初始化不同的推送
        3. 统一配置KEY
        4. 统一初始化方法

    2017-01-22
        1. 极光和小米可以使用了


##说明
    1. 极光版本 jpush V3.0.0 jcore V1.0.0
    2. 小米推送版本 V3.1.2
    3. 华为推送版本 V2.7.05

## 其他
* 极光推送 [https://docs.jiguang.cn/jpush/client/Android/android_guide/](https://docs.jiguang.cn/jpush/client/Android/android_guide/)
* 小米推送 [http://dev.xiaomi.com/doc/?p=544](http://dev.xiaomi.com/doc/?p=544)
* 华为推送 [http://developer.huawei.com/consumer/cn/wiki/index.php](http://developer.huawei.com/consumer/cn/wiki/index.php?title=HMS%E5%BC%80%E5%8F%91%E6%8C%87%E5%AF%BC%E4%B9%A6-PUSH%E6%9C%8D%E5%8A%A1%E6%8E%A5%E5%8F%A3)