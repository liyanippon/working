package com.beanu.l2_push;

/**
 * 手机类型
 * Created by Beanu on 2017/2/10.
 */

public enum PhoneTarget {
    MIUI, EMUI, JPUSH
}
