package com.beanu.l2_pay;

/**
 * Created by lizhihua on 2017/1/18.
 */

public interface IPay {
    void doPay();
}
