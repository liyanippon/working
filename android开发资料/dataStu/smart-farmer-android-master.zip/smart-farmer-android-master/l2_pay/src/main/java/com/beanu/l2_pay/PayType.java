package com.beanu.l2_pay;

/**
 * Created by lizhihua on 2017/1/18.
 */

public enum PayType {
    ALI,
    WX
}
