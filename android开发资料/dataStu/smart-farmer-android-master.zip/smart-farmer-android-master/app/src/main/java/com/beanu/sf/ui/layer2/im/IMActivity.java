package com.beanu.sf.ui.layer2.im;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class IMActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(com.beanu.l2_im.R.layout.activity_im);
    }
}
