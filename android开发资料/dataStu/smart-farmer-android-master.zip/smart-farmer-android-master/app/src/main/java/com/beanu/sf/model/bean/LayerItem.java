package com.beanu.sf.model.bean;

/**
 * ITEM
 * Created by Beanu on 16/11/4.
 */

public class LayerItem {

    private String title;
    private Class clsName;

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Class getClsName() {
        return clsName;
    }

    public void setClsName(Class clsName) {
        this.clsName = clsName;
    }
}
