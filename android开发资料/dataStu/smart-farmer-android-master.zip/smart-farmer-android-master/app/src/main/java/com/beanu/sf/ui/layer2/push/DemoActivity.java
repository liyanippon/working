//package com.beanu.sf.ui.layer2.push;
//
//import android.support.v7.app.AppCompatActivity;
//import android.os.Bundle;
//
//import com.beanu.l2_push.PushManager;
//import com.beanu.l2_push.R;
//
//public class DemoActivity extends AppCompatActivity {
//
//    PushListener mPushListener = new PushListener();
//
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_demo);
//
//
//        PushManager.register(this, true, mPushListener);
//    }
//
//
//}
