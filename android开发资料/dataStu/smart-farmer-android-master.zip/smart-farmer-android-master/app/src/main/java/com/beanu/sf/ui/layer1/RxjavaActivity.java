package com.beanu.sf.ui.layer1;

import android.os.Bundle;

import com.beanu.arad.base.ToolBarActivity;
import com.beanu.sf.R;

public class RxjavaActivity extends ToolBarActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rxjava);
    }
}
