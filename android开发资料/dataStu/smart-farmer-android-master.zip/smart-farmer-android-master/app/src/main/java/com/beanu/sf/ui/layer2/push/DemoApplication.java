//package com.beanu.sf.ui.layer2.push;
//
//import android.app.Application;
//
//import com.beanu.l2_push.util.Const;
//
///**
// * 测试
// * Created by Beanu on 2016/12/23.
// */
//
//public class DemoApplication extends Application {
//
//    public static final String TAG = "l2_push";
//
//    @Override
//    public void onCreate() {
//        super.onCreate();
//
//        Const.setMiUI_APP("id", "key");
//    }
//}
