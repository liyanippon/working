package com.beanu.l3_common.util;

/**
 * 常量
 * Created by Beanu on 16/9/18.
 */
public class Constants {

    public static String URL = "http://192.168.10.174:801";
    public static String IMAGE_URL = "http://192.168.10.174:801/static/";

    //内部存储key值
    public static final String P_ACCOUNT = "loujjhhg";
    public static final String P_PWD = "oyyjhg";
    public static final String P_User_Id = "mnhjhhhh";
    public static final String P_ISFIRSTLOAD = "asfaagdse";

}
