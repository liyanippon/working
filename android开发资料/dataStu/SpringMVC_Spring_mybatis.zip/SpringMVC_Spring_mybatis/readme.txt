1、访问路径：localhost:8080/SpringMVC_Spring_mybatis/
2、数据库配置，一定要和自己的设置一样
<property name="driverClassName" value="com.mysql.jdbc.Driver" />
<property name="url" value="jdbc:mysql://localhost:3306/mybatis" />
<property name="username" value="root" />
<property name="password" value="123456" />
3、jdk需要1.6以上
4、项目需要运行在tomcat等服务器上
