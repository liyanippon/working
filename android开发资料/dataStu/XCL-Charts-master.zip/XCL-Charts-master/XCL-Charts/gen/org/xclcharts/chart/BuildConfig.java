/** Automatically generated file. DO NOT MODIFY */
package org.xclcharts.chart;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}