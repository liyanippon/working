# AnalyticalWord
 Analytical doc files and docx files
 android使用poi需要对poi-scratchpad和xmlbeans重新编译下
 重新编译方法javac -cp d:\poi-3.14-20160307.jar;d:\poi-scratchpad-3.14-20160307.jar; d:\AbstractWordUtils.java
使用poi进行解析word,支持支持doc,docx,XLSX,xls
