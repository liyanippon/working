package com.analyticalword;

/**
 * Created by Donald on 2016/5/23.
 */
public class AplicationBaseConfig {
    /**水利外部基地址*/
    public static String BASE_FILE = "/sdcard/analyticalword/";
    /**查看word缓存路径*/
    public static String BASE_WORD_FILE_DIR = "/sdcard/analyticalword/library";
    /**图片缓存文件夹*/
    public static String BASE_WORD_FILE = "analyticalword/library";

}

