package com.kelin.scrollablepanel.sample;

/**
 * Created by kelin on 16-11-18.
 */

public class DateInfo {
    private String Date;
    private String week;

    public String getDate() {
        return Date;
    }

    public void setDate(String date) {
        Date = date;
    }

    public String getWeek() {
        return week;
    }

    public void setWeek(String week) {
        this.week = week;
    }
}
