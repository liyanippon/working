# ScanCode
使用zxing封装的android扫描全功能系列，包括二维码扫描，条形码扫描，二维码生成，条形码生成，从图片中扫描二维码或者条形码,闪光灯控制。<br/>
优点：<br/>
    1.该有的功能一个都不少！<br/>
    2.扫描界面布局xml完成，可自行订制！<br/>
    3.不乱码，不变形！<br/>
    4.扫描后可得到扫描的截图！<br/>
    5.支持连续扫描！<br/>
    6.在一个项目中可多处使用，根据CommonScanActivity在多写一个自己的扫描界面就行了！<br/>
#项目截图
![](https://github.com/liang530/ScanCode/raw/master/images/main.png)<br/>

![](https://github.com/liang530/ScanCode/raw/master/images/createCode.png)<br/>
![](https://github.com/liang530/ScanCode/raw/master/images/scanCode.png)<br/>
![](https://github.com/liang530/ScanCode/raw/master/images/scan2code.png)<br/>
![](https://github.com/liang530/ScanCode/raw/master/images/scan_bar_code.png)<br/>
![](https://github.com/liang530/ScanCode/raw/master/images/scan_photo.png)<br/>
