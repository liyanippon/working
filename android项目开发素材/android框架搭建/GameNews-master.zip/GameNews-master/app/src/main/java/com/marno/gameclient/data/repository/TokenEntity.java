package com.marno.gameclient.data.repository;

/**
 * Created by marno on 2016/7/25/20:21.
 */
public class TokenEntity {
    public String userToken;
}
