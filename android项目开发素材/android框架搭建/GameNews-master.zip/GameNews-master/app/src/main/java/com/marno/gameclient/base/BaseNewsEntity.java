package com.marno.gameclient.base;

/**
 * Created by marno on 2016/7/21/20:59.
 * 所有POJO的基类
 */
public class BaseNewsEntity<T> {

    public int ret;
    public int flag;
    public T data;
}
