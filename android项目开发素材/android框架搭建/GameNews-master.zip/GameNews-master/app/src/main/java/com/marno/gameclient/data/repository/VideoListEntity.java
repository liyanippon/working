package com.marno.gameclient.data.repository;

import com.marno.gameclient.data.models.VideoEntity;

import java.util.List;

/**
 * Created by marno on 2016/7/25/20:23.
 */
public class VideoListEntity {
    public String pageNo;
    public List<VideoEntity> videoList;
}
