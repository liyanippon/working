package com.marno.gameclient.utils;

/**
 * Created by marno on 2016/7/21/21:03.
 */
public class C {

    /**
     * 视频token
     */
    public static String token = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.ckFwdWxVeXZHem5wcVJENjJVV2V3NGJxV3BmN0pvUWNvMlhVSVlKVXZPUXBVSm1nWUFZSzdkajRLSm45R1l4WA.aHcSWw8bJVu3ABqYtbMS9bBZTegQr_inV0p2azoVOE8";

    public static final String
            CATE_ID = "cate_id",
            MAX = "max",
            PAGESIZE = "pageSize",
            CATEID = "catid",
            TOKEN = "token",
            DIVICE = "device",
            PAGENO = "pageNo",
            F_Token = "token";



}
