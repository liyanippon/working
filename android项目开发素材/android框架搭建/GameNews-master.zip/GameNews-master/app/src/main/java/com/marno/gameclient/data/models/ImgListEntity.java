package com.marno.gameclient.data.models;

import java.util.List;

/**
 * Created by marno on 2016/7/24/16:59.
 */
public class ImgListEntity {
    public boolean error;
    public List<ImageEntity> results;
}
